# Job Title Optimizer
Ottimizza i job title per profili blue collar con suggerimenti basati su Google Trends, Indeed e LinkedIn.
